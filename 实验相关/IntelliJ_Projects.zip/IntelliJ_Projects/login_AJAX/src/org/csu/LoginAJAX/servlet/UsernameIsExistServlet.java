package org.csu.LoginAJAX.servlet;

import org.csu.LoginAJAX.domain.Account;
import org.csu.LoginAJAX.sevice.AccountService;

import java.io.IOException;
import java.io.PrintWriter;


public class UsernameIsExistServlet extends javax.servlet.http.HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        String username = request.getParameter("username");
        Account account = new Account();
        account.setUsername(username);
        AccountService service = new AccountService();

        response.setContentType("text/xml");
        PrintWriter out = response.getWriter();

        if(service.usernameIsExist(account)){
            out.println("<msg>Exist</msg>");
        }
        else {
            out.println("<msg>NotExist</msg>");
        }
        out.flush();
        out.close();
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {

    }
}
