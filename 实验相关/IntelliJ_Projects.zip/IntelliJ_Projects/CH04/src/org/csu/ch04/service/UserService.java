package org.csu.ch04.service;

import org.csu.ch04.domain.User;
import org.csu.ch04.persistence.UserDAO;

public class UserService {
    private UserDAO userDAO;
    public User login(User loginUser){
        //其他业务逻辑相关代码
        userDAO = new UserDAO();
        return userDAO.findUserByUsernameAndPassword(loginUser);
    }
}
