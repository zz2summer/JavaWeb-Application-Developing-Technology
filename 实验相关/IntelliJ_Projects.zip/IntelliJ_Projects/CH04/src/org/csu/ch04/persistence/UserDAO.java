package org.csu.ch04.persistence;

import org.csu.ch04.domain.User;

public class UserDAO {
    public User findUserByUsernameAndPassword(User loginUser){
    if(loginUser.getUsername().equals("admin") && loginUser.getPassword().equals("123")){
        return loginUser;
    }else {
        return null;
    }
}
}
