package org.csu.ch04.web.servlet;

import org.csu.ch04.domain.User;
import org.csu.ch04.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class LoginServlet extends HttpServlet {
    private User loginUser;
    private UserService userService;

    private static final String LOGIN_FORM = "/WEB-INF/jsp/login.jsp";
    private static final String MAIN_FORM = "/WEB-INF/jsp/main.jsp";

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        loginUser = new User();
        loginUser.setUsername(username);
        loginUser.setPassword(password);

        userService = new UserService();
        loginUser = userService.login(loginUser);

        if(loginUser != null){
            req.getRequestDispatcher(MAIN_FORM).forward(req, resp);
        }
        else{
            req.getRequestDispatcher(LOGIN_FORM).forward(req, resp);
        }
    }
}
