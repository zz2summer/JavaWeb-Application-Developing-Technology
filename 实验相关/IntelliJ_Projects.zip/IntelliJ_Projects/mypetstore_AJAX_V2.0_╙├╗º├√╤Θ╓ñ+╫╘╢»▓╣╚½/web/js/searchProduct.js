var xmlHttpRequest;
function createXMLHttpRequest()
{
    if (window.XMLHttpRequest) //非IE浏览器
    {
        xmlHttpRequest = new XMLHttpRequest();
    }
    else if (window.ActiveObject)//IE6以上版本的IE浏览器
    {
        xmlHttpRequest = new ActiveObject("Msxml2.XMLHTTP");
    }
    else //IE6及以下版本IE浏览器
    {
        xmlHttpRequest = new ActiveObject("Microsoft.XMLHTTP");
    }
}

function searchPI() {
    //var username = document.NewAccountForm.username.value;
    var keyword = document.getElementById('keyword').value;
    sendRequest("findResultServlet?keyword=" + keyword);
}

function sendRequest(url) {
    createXMLHttpRequest();
    xmlHttpRequest.open("GET", url, true);
    xmlHttpRequest.onreadystatechange = processResponse;
    xmlHttpRequest.send(null);
}

function processResponse() {
    if (xmlHttpRequest.readyState == 4) {
        if (xmlHttpRequest.status == 200) {
            var resp = xmlHttpRequest.responseText;
            var resp2 = resp.split(',');

            var div2 = document.getElementById('searchMsg');
            div2.innerHTML = "<div><font color='red'>" + resp2 + "</font></div>";
            /*
            var keyword = document.getElementById("keyword");
            var context1 = document.getElementById("context1");

                var content=$(this).value();
                //如果当前搜索内容为空，无须进行查询
                if(content == null){
                    context1.css("display","none");
                }
                //由于浏览器的缓存机制 所以我们每次传入一个时间
                var time=new Date().getTime();
                $.ajax({
                    type:"post",
                    //新建一个名为findBooksAjaxServlet的servlet
                    url:"${pageContext.request.contextPath}findResultServlet",
                    data:{name:content,time:time},
                    success:function(data){
                        //拼接html
                        var res=data.split(",");
                        var html="";
                        for(var i=0;i<res.length;i++){
                            //每一个div还有鼠标移出、移入点击事件
                            html+="<div onclick='setSearch_onclick(this)' onmouseout='changeBackColor_out(this)' onmouseover='changeBackColor_over(this)'>"+res[i]+"</div>";
                        }
                        context1.innerHTML(html);
                        //显示为块级元素
                        context1.css("display","block");
                    }
                });
             */
        }
    }
}

//鼠标移动到内容上
function changeBackColor_over(div){
    div.css("background-color","#CCCCCC");
}
//鼠标离开内容
function changeBackColor_out(div){
    div.css("background-color","");
}
//将点击的内容放到搜索框
function setSearch_onclick(div){
    var keyword = document.getElementById("keyword");
    var context1 = document.getElementById("context1");
    keyword.appendChild(document.createTextNode(div));
    //$("#keyword").value(div.innerText);
    context1.css("display","none");
}