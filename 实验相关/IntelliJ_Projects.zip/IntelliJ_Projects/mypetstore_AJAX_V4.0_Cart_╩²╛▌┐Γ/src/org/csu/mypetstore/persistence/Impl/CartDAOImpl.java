package org.csu.mypetstore.persistence.Impl;

import org.csu.mypetstore.domain.Cart;
import org.csu.mypetstore.persistence.CartDAO;

public class CartDAOImpl implements CartDAO {
    @Override
    public void insertCart(Cart cart) {

    }

    @Override
    public void removeCart(Cart cart) {

    }

    @Override
    public void removeItem(String workingItemId) {

    }
}
