package org.csu.mypetstore.service;

import org.csu.mypetstore.persistence.CartDAO;
import org.csu.mypetstore.persistence.CategoryDAO;
import org.csu.mypetstore.persistence.Impl.CartDAOImpl;
import org.csu.mypetstore.persistence.Impl.CategoryDAOImpl;

public class CartService {
    private CartDAO cartDAO;
    private CategoryDAO categoryDAO;

    public CartService(){
        cartDAO = new CartDAOImpl();
        categoryDAO = new CategoryDAOImpl();
    }
    /*
    public void addItem(String workingItemId){
        if(cart == null){
            //第一次使用购物车
            cart = new Cart();
        }

        if(cart.containsItemId(workingItemId)){
            //已有该物品，数量加一
            cart.incrementQuantityByItemId(workingItemId);
        }else{
            catalogService = new CatalogService();
            boolean isInStock = catalogService.isItemInStock(workingItemId);
            Item item = catalogService.getItem(workingItemId);
            cart.addItem(item, isInStock);
            session.setAttribute("cart", cart);
    }
    */
    public void removeItem(String workingItemId){

    }
}
