package org.csu.mypetstore.persistence;

import org.csu.mypetstore.domain.Cart;

public interface CartDAO {

    //加入商品到购物车
    void insertCart(Cart cart);
    //移除购物车
    void removeCart(Cart cart);
    //移除商品
    void removeItem(String workingItemId);

}
