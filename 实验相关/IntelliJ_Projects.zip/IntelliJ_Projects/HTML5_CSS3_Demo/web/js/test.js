function f() {
    var bbb = document.getElementById('usernameMsg');
    bbb.textContent = "jkljalsdkjfla";
}