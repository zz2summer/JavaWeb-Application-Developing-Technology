var el = document.getElementById('one');

el.className = 'cool';