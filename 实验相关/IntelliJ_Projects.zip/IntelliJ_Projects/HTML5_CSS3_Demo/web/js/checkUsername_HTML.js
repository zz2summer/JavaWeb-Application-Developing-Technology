function checkUsername() {
    var elUsername = document.getElementById('username');
    var elMsg = document.getElementById('feedback');
    if(elUsername.value.length < 5){
        elMsg.textContent = 'Username must be 5 characters or more';
    }else{
        elMsg.textContent = '';
    }
}