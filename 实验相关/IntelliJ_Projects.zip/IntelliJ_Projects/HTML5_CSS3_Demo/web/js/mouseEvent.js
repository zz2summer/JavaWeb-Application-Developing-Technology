function showInform() {
    document.getElementById("test").style.display = "block";
}

function hiddenInform() {
    document.getElementById("test").style.display = "none";
}