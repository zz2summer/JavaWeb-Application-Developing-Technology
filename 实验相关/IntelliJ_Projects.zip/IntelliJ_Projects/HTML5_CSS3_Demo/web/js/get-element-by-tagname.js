var elements = document.getElementsByTagName('li');

if(elements.length > 0){
    var el = elements[0];
    el.className = 'cool';
}