package org.csu.demo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

//配置语句，效果等同在xml文件中配置
@WebServlet(name = "HelloWorld-HTTP", urlPatterns = "/hello-http")
public class HelloWorldHTTPServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //response.setContentType("text/html");
        //HTTPServlet默认使用html方式
        PrintWriter out = resp.getWriter();
        out.println("<html><head></head><body>Hello World! --HTTPServlet</body></html>");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
