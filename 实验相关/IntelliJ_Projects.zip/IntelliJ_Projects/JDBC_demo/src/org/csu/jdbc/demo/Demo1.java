package org.csu.jdbc.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Demo1 {
    public static void main(String[] args){
        try {
            //1.加载驱动
            Class.forName("com.mysql.jdbc.Driver");
            //2.获得连接    MySQL在高版本需要指明是否进行SSL连接   ?characterEncoding=utf8&useSSL=true
            Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1/demo?characterEncoding=utf8&useSSL=true",
                    "root","root1234");
            //验证是否连接成功
            //System.out.println(connection);

            //3.创建执行对象
            Statement statement = connection.createStatement();
            //对数据库进行增加操作
            //String sql = "insert into userinfo values (3, 'zhang', 15, 'zhang@qq.com')";
            String sql = "insert into userinfo values (4, 'wang', 18, 'wang@163.com')";

            //4.执行语句
            int result = statement.executeUpdate(sql);

            //5.检验创建是否成功
            if (result == 1){
                System.out.println("Insert Success!");
            }

            statement.close();

            //关闭connection
            connection.close();

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
