package org.csu.jdbc.demo.jdbc.better;

import java.sql.Connection;
import java.sql.Statement;

public class UserDAO {
    //存放对表的所有操作，便于代码重用

    //插入
    private static String insertUserSQL = "insert into userinfo values (?, ?, ?, ?)";

    public boolean insertUser(User user){
        boolean flag = false;
        try {
            Connection connection = DButil.getConnection();
            Statement statement = connection.createStatement();
            int result = statement.executeUpdate(insertUserSQL);
            if (result == 1){
                flag = true;
            }

            DButil.closeStatement(statement);
            DButil.closeConnection(connection);


        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }
}
