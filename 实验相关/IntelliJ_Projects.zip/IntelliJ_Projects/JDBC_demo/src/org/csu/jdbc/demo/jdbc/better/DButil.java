package org.csu.jdbc.demo.jdbc.better;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DButil {
    private static String drive = "com.mysql.jdbc.Driver";
    private static String url = "jdbc:mysql://127.0.0.1/demo?characterEncoding=utf8&useSSL=true";
    private static String username = "root";
    private static String password = "root1234";

    //获取连接
    public static Connection getConnection() throws Exception {
        Connection connection = null;

        Class.forName(drive);
        connection = DriverManager.getConnection(url, username, password);

        return connection;
    }

    //关闭连接
    public static void closeConnection(Connection connection) throws Exception {
        if(connection != null){
            connection.close();
        }
    }

    public static void closeStatement(Statement statement) throws Exception {
        if (statement != null){
            statement.close();
        }
    }
}
