package org.csu.jdbc.demo;

import java.sql.*;

//数据库查询语句
public class Demo2 {
    public static void main(String[] args){
        try {
            //1.加载驱动
            Class.forName("com.mysql.jdbc.Driver");
            //2.获得连接    MySQL在高版本需要指明是否进行SSL连接   ?characterEncoding=utf8&useSSL=true
            Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1/demo?characterEncoding=utf8&useSSL=true",
                    "root","root1234");
            //验证是否连接成功
            //System.out.println(connection);

            //3.创建执行对象
            Statement statement = connection.createStatement();

            /*
            //单个数据查询
            //4.对数据库进行查询操作
            String sql = "select * from userinfo where id = 3";

            //5.执行查询
            ResultSet resultSet = statement.executeQuery(sql);

            //6.检验执行结果
            if(resultSet.next()){
                System.out.println(resultSet.getInt(1));
                System.out.println(resultSet.getString("name"));
                System.out.println(resultSet.getInt(3));   //age也是一样的效果
                System.out.println(resultSet.getString(4));
            }
            */

            //查询整张表格信息
            //4.对数据库进行查询操作
            String sql = "select * from userinfo";

            //5.执行查询
            ResultSet resultSet = statement.executeQuery(sql);

            //6.检验执行结果
            while(resultSet.next()){
                System.out.print(resultSet.getInt(1) + "\t");
                System.out.print(resultSet.getString("name") + "\t");
                System.out.print(resultSet.getInt(3) + "\t");   //age也是一样的效果
                System.out.println(resultSet.getString(4));
            }

            //关闭该结果集
            resultSet.close();
            //关闭该对象
            statement.close();
            //关闭connection
            connection.close();

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
